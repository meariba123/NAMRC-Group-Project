<?php

$db = new SQLite3('../../../NAMRC copy/NAMRC.db');