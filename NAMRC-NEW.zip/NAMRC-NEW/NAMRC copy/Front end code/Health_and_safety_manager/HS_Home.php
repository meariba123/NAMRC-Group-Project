<!DOCTYPE html>
<html lang="en">
<head>
    <title>Nuclear AMRC</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../site.css"/>
</head>

<body>
<div class="container">
    <header class="header">
        <div class="logo">
            <img class="logo-img" src="logo.png" alt="Nuclear AMRC Logo">
        </div>
        <nav class="navigation">
            <ul class="left-options">
            <li><a href="HS_View.php">View employees</a></li>
            <li><a href="HS_Viewcell.php">View cells</a></li>
            <li><a href="HS_Viewtraining.php">View available training/certifications</a></li>
            <li><a href="HS_Addcertification.php">Add certification & training</a></li>
            <li><a href="HS_Profile.php">View Profile</a></li>
            <li class="right-link"><a href="../Home.html">Logout</a></li>
            </ul>
        </nav>
    </header>
</div>

<div class="banner">
    <img class="featureImage" src="../images/Health_image.png" alt="Health and Safety Image">
    <div class="overlay"></div>
    <div class="container">
        <div class="paragraph">
            <h2>Health and Safety Manager</h2>
            <p>As a Health and Safety manager, you have the ability to view everyone in the database and update their details, as well as remove them from the system.</p>
            <p>You can also view available training and the certifications required for each cell. Additionally, you have the capability to view all employees in the system, update their details, delete them, and create new certifications.</p>
        </div>
    </div>
</div>

<div class="banner">
    <div class="overlay"></div>
    <div class="container">
        <div class="paragraph">
            <h1 class="featureTitle">Health and Safety Regulations <br> in a Nuclear Field</h1>
            <h2 class="topicTitle">These must be monitored and identified to ensure safe and healthful working conditions in NAMRC.</h2>
            <p>Compliance with these regulations is essential for creating a healthy workplace environment in manufacturing facilities.</p>
            <img src="pic-22.png" alt="pic-22 Image" class="featureImage">
        </div>

        <div class="paragraph">
            <h2 class="topicTitle">Risk Assessment and Management</h2>
            <p>It is a requirement to conduct risk assessments to identify potential hazards in the workplace and implement measures to control or mitigate those risks.</p>
        </div>

        <div class="paragraph">
            <h2 class="topicTitle">Safe Work Practices</h2>
            <p>Establishing and enforcing safe work practices to ensure that employees are trained to perform their jobs safely. This includes training on equipment operation, handling hazardous materials, and emergency procedures.</p>
        </div>

        <div class="paragraph">
            <h2 class="topicTitle">Machine Safety</h2>
            <p>Machinery in manufacturing facilities must comply with safety standards to prevent accidental contact with moving parts or exposure to hazardous energy sources.</p>
        </div>

        <div class="paragraph">
            <h2 class="topicTitle">Chemical Safety</h2>
            <p>Manufacturers must comply with regulations for the safe handling, storage, and disposal of hazardous chemicals used in the manufacturing process.</p>
        </div>

        <div class="paragraph">
            <h2 class="topicTitle">Emergency Preparedness</h2>
            <p>Manufacturers must have emergency response plans in place. This includes providing training on emergency procedures, evacuation routes, and the use of firefighting equipment and first aid supplies.</p>
        </div>
    </div>
</div>


<footer class="footer">
        <div class="container">
            <div class="contact-info">
                <h3>Contact</h3>
                <p>+44 (0)114 222 9900</p>
                <p>enquiries@namrc.co.uk</p>
            </div>
            <div class="links">
                <h3>Links</h3>
                <a href="https://www.linkedin.com/company/nuclear-amrc/">LinkedIn</a>
            </div>
            <div class="rights">
                <h3>© 2024 Nuclear AMRC. All Rights Reserved.</h3>
            </div>
        </div>
    </footer>
</body>
</html>