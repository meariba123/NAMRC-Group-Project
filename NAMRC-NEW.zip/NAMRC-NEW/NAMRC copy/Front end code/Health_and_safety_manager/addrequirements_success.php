<!-- Add certificate success done by ariba -->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Nuclear AMRC</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../site.css"/>
</head>
<body>
<?php
 require("../navbar2.php");
 ?>

<div class="content">
    <h2>Certification was successfully added. Press the "Next" icon to add a training.</h2>
    <form method="post" action="HS_Addrequirements.php">
        <input type="submit" name="Next" value="Next" class="returnbutton">
    </form>
    <form method="post" action="HS_Addcertification.php">
        <input type="submit" name="Back" value="Back" class="returnbutton">
    </form>
</div>
<footer class="footer">
        <div class="container">
            <div class="contact-info">
                <h3>Contact</h3>
                <p>+44 (0)114 222 9900</p>
                <p>enquiries@namrc.co.uk</p>
            </div>
            <div class="links">
                <h3>Links</h3>
                <a href="https://www.linkedin.com/company/nuclear-amrc/">LinkedIn</a>
            </div>
            <div class="rights">
                <h3>© 2024 Nuclear AMRC. All Rights Reserved.</h3>
            </div>
        </div>
    </footer>
</body>

</html>

