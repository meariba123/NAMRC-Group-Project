<!-- Viewing done by Ariba !-->
<?php
session_start();
function getProfile(){
    
    
 

    $arrayResult = array(); 
    $email = $_SESSION["HSM_email"];
    $db = new SQLite3('../../../NAMRC copy/NAMRC.db');
    $sql = "SELECT * FROM 'Health and Safety Managers, Officers' h INNER JOIN Address a ON a.address_id = h.address_id WHERE HSM_email = :email ";
  
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':email', $email, SQLITE3_TEXT);
    $result = $stmt->execute();

    while ($row = $result->fetchArray()){ 
        $arrayResult [] = $row; 
    }
   
    return $arrayResult;
    
}


?>