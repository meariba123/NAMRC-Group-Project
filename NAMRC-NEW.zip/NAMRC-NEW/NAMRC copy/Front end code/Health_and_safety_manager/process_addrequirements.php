<!-- process of adding a certificate done by ariba -->

<?php
session_start();

try {
    $db = new SQLite3('../../../NAMRC copy/NAMRC.db');
} catch (Exception $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $techID = $_POST['tech_id'];
    $certificationID = $_POST['certificate_id'];
    $cellLength = $_POST['cell_length'];

    $stmt = $db->prepare("INSERT INTO 'Operator Certification' (tech_id, certification_ID, expiry_date) VALUES (?, ?, ?)");
    
    if (!$stmt) {
        die("Error in preparing statement: " . $db->lastErrorMsg());
    }

    $stmt->bindParam(1, $techID, SQLITE3_INTEGER);
    $stmt->bindParam(2, $certificationID, SQLITE3_INTEGER);
    $stmt->bindParam(3, $cellLength, SQLITE3_TEXT);
    $result = $stmt->execute();

    if ($result) {
        header("Location: addrequirement_success.php");
        exit();
    } else {
        header("Location: addrequirement_unsuccessful.php");
        exit();
    }
} else {
    header("Location: HS_Addrequirements.php");
    exit();
}
?>
