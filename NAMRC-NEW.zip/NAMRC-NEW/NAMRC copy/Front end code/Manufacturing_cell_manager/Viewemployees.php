<!-- Viewing done by Ariba !-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</body>
<div class="container pb-5">
    <main role="main" class="pb-3">
        <h2 class="text-center professional-purple">View Technical-Staff:</h2><br>

        <?php
        session_start();
        require_once 'ViewemployeesSQL.php';

        // gets the logged in MCM's ID value
        if (isset($_SESSION['mcm_id'])) {
        $logged_in_mcm_id = $_SESSION['mcm_id'];
        $MCM = getMCM($logged_in_mcm_id);
        } else {
        header("Location: MCM_Login.php");
        exit;
        }

        // gets the employees who are in the Cell managed by the logged-in MCM
        $mcm_id = $_SESSION['mcm_id'];
        $Employee = getEmployee($mcm_id);
        ?>

        <div class="row">
    <div class="col-5">
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <br>
                <th style="min-width: 75px;">Tech ID</th> 
                                <th style="min-width: 75px;">First Name</th>
                                <th style="min-width: 75px;">Middle Name</th>  
                                <th style="min-width: 75px;">Last Name</th> 
                                <th style="min-width: 175px;">Email</th> 
                                <th style="min-width: 75px;">Password</th>
                                <th style="min-width: 75px;">Address ID</th>  
                                <th style="min-width: 75px;">Dob</th> 
                                <th style="min-width: 75px;">Cell ID</th> 
                                <th style="min-width: 75px;">Department ID</th> 
                                <th style="min-width: 75px;">Update</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($Employee as $employee): ?>
                                <tr>
                                    <td><?php echo $employee['tech_ID']?></td>
                                    <td><?php echo $employee['tech_fname']?></td>
                                    <td><?php echo $employee['tech_mname']?></td>
                                    <td><?php echo $employee['tech_lname']?></td>
                                    <td><?php echo $employee['tech_email']?></td>
                                    <td><?php echo $employee['tech_password']?></td>
                                    <td><?php echo $employee['address_id']?></td>
                                    <td><?php echo $employee['tech_dob']?></td>
                                    <td><?php echo $employee['cell_ID']?></td>
                                    <td><?php echo $employee['DEP_ID']?></td>
                                    <td><a href="MCM_Update.php?tech_ID=<?php echo $employee['tech_ID'];?>">Update</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <h2>View MCM:</h2><br>
            <div class="row">
                <div class="col-5">
                    <table class="table table-bordered table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th style="min-width: 75px;">MCM ID</th> 
                                <th style="min-width: 75px;">First Name</th>
                                <th style="min-width: 75px;">Middle Name</th>  
                                <th style="min-width: 75px;">Last Name</th> 
                                <th style="min-width: 175px;">Email</th> 
                                <th style="min-width: 75px;">Password</th>
                                <th style="min-width: 75px;">Address ID</th>  
                                <th style="min-width: 75px;">Dob</th> 
                                <th style="min-width: 75px;">Dep ID</th>
                                <th style="min-width: 75px;">Update</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($MCM as $mcm): ?>
                                <tr>
                                    <td><?php echo $mcm['MCM_ID']?></td>
                                    <td><?php echo $mcm['MCM_fname']?></td>
                                    <td><?php echo $mcm['MCM_mname']?></td>
                                    <td><?php echo $mcm['MCM_lname']?></td>
                                    <td><?php echo $mcm['MCM_email']?></td>
                                    <td><?php echo $mcm['MCM_password']?></td>
                                    <td><?php echo $mcm['address_id']?></td>
                                    <td><?php echo $mcm['MCM_dob']?></td>
                                    <td><?php echo $mcm['DEP_ID']?></td>
                                    <td><a href="MCM_UpdateMCM.php?MCM_ID=<?php echo $mcm['MCM_ID'];?>">Update</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
