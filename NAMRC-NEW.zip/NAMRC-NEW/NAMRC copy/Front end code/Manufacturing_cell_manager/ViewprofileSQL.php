<!-- Viewing done by Ariba !-->
<?php
session_start();
function getProfile(){
    
    
 

    $arrayResult = array(); 
    $email = $_SESSION["MCM_email"];
    $db = new SQLite3('../../../NAMRC copy/NAMRC.db');
    $sql = "SELECT * FROM 'Manufacturing Cell Manager' m INNER JOIN Address a ON a.address_id = m.address_id WHERE MCM_email = :email ";
  
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':email', $email, SQLITE3_TEXT);
    $result = $stmt->execute();

    while ($row = $result->fetchArray()){ 
        $arrayResult [] = $row; 
    }
   
    return $arrayResult;
    
}


?>