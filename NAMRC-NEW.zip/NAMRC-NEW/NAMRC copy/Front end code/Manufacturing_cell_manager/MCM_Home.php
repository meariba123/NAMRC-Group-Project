<!DOCTYPE html>
<html lang="en">
<head>
    <title>Nuclear AMRC</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../site.css"/>
</head>
<body>
<div class="container">
    <header class="header">
        <div class="logo">
            <img class="logo-img" src="logo.png" alt="Nuclear AMRC Logo">
        </div>
        <nav class="navigation">
            <ul class="left-options">
                <li><a href="MCM_View.php">View Employees</a></li>
                <li><a href="MCM_Viewcell.php">View Cells</a></li>
                <li><a href="MCM_Viewtraining.php">View Available Training</a></li>
                <li><a href="MCM_Profile.php">View Profile</a></li>
                <li class="right-link"><a href="../Home.html">Logout</a></li>
            </ul>
        </nav>
    </header>
</div>

<div class="banner">
    <img class="featureImage" src="../images/manufacturing_image.png" alt="Manufacturing Image">
    <div class="overlay"></div>
    <div class="container">
        <div class="paragraph">
            <h2>Manufacturing Cell Manager</h2>
            <p>As a manufacturing cell manager, you are in charge of the employees that work in your cell.</p>
            <p>You are able to view the details of all technical staff as well as the other cell managers.</p>
            <p>You are able to update the details of users (e.g., updating the certification a technical staff has) and you can remove users from the system as well.</p>
        </div>
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Pro-Beam K2000 EBW Chamber</h2>
        <p>Designed for high-precision welding applications, providing a controlled environment for electron beam welding processes</p>
        <p>Its advanced features ensure high-quality welds with efficiency and precision.</p>
        <img src="pic.png" alt="pic Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Pro-Beam K25 EBW Chamber</h2>
        <p>Delivers precise electron beam welding in a compact design, ideal for smaller-scale industrial applications.</p>
        <p>With advanced technology and reliable performance, it ensures high-quality welds with efficiency and accuracy.</p>
        <img src="pic-2.png" alt="pic-2 Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Diode Laser Cell</h2>
        <p>Offers precise laser cutting and welding capabilities in a compact and versatile package.</p>
        <p>Reliable solution for high-quality material processing across diverse applications.</p>
        <img src="pic-3.png" alt="pic-3 Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Disk Laser Cell</h2>
        <p>Laser processing system that utilizes disk laser technology for precise cutting and welding applications.</p>
        <p>Its high-power output and advanced features ensure fast, accurate, and reliable cutting and welding.</p>
        <img src="pic-4.png" alt="pic-4 Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">ABB/Fronius robotic welding cell</h2>
        <p>Integrates ABB's advanced robotics with Fronius's cutting-edge welding technology, offering a comprehensive solution for automated welding tasks.</p>
        <p>Combines precision robotic motion control with high-quality welding capabilities, ensuring efficient and consistent welds across various workpieces.</p>
        <img src="pic-6.png" alt="pic-6 Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Modular intelligent manufacturing and inspection cell</h2>
        <p>Versatile system designed to streamline production processes while ensuring quality control.</p>
        <p>Integrates seamlessly into existing production lines, providing real-time monitoring and analysis</p>
        <img src="pic-7.png" alt="pic-7 Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Dorries Contumat VTL</h2>
        <p>High-precision machining system designed for heavy-duty turning operations.</p>
        <p>Offers exceptional stability and rigidity, allowing for accurate machining of large and heavy workpieces.</p>
        <img src="pic-8.png" alt="pic-8 Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Soraluce FX12000</h2>
        <p>Milling machine renowned for its exceptional precision and versatility in large-scale machining tasks.</p>
        <p>Ensures efficient and accurate machining of complex parts, preferred choice for demanding industrial applications. </p>
        <img src="pic-9.png" alt="pic-9 Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Heckert HEC1800</h2>
        <p>Heavy-duty horizontal machining center designed for high-performance machining of large workpieces.</p>
        <p>Enables efficient milling, drilling, and tapping operations on a variety of materials.</p>
        <img src="pic-10.png" alt="pic-10 Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Heckert HEC800</h2>
        <p>Versatile horizontal machining center renowned for its precision and efficiency in medium to large-scale machining operations.</p>
        <p>Ensures accurate and reliable machining for a wide range of industrial applications, making it a valuable asset in manufacturing environments.</p>
        <img src="pic-11.png" alt="pic-11 Image" class="featureImage">
    </div>
</div>

<div class="feature-container">
    <div class="feature">
        <h2 class="topicTitle">Hartford LG-500</h2>
        <p>Robust and high-precision CNC lathe designed for medium to large-scale machining tasks.</p>
        <p>Offers exceptional stability and accuracy for turning operations on various materials, equipped with advanced controls and tooling options.</p>
        <img src="pic-12.png" alt="pic-12 Image" class="featureImage">
    </div>
</div>






<footer class="footer">
        <div class="container">
            <div class="contact-info">
                <h3>Contact</h3>
                <p>+44 (0)114 222 9900</p>
                <p>enquiries@namrc.co.uk</p>
            </div>
            <div class="links">
                <h3>Links</h3>
                <a href="https://www.linkedin.com/company/nuclear-amrc/">LinkedIn</a>
            </div>
            <div class="rights">
                <h3>© 2024 Nuclear AMRC. All Rights Reserved.</h3>
            </div>
        </div>
    </footer>
    
    

</body>
</html>