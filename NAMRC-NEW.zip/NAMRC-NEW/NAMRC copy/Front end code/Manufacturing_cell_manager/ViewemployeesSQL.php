<!-- Viewing done by Ariba !-->

<?php
function getEmployee($mcm_id) {
    $arrayResult = array(); 
    $db = new SQLite3('../../../NAMRC copy/NAMRC.db');
    
    // get the value from cells (cell_ID) thats value matches up with the mcm_id
    $cell_id_query = "SELECT cell_ID FROM Cells WHERE MCM_ID = :mcm_id";
    $stmt_cell_id = $db->prepare($cell_id_query);
    $stmt_cell_id->bindValue(':mcm_id', $mcm_id, SQLITE3_INTEGER);
    $result_cell_id = $stmt_cell_id->execute();
    
    // check if theres a valid result
    if ($result_cell_id) {
        $cell_id_row = $result_cell_id->fetchArray();
        $cell_id = $cell_id_row['cell_ID'];

        // Get technical staff that which belong to the same cell as the one of the person logged in
        $sql = "SELECT * FROM 'Technical Staff' WHERE cell_ID = :cell_id";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':cell_id', $cell_id, SQLITE3_INTEGER);
        $result = $stmt->execute();

        while ($row = $result->fetchArray()) { 
            $arrayResult[] = $row; 
        }
    } else {
        // show there is an error if there is no Cell ID found
        echo "Cell ID not found for the logged-in MCM manager.";
    }

    return $arrayResult;
}


function getMCM($logged_in_mcm_id) {
    //only show logged in MCM
    $arrayResult = array(); 
    $db = new SQLite3('../../../NAMRC copy/NAMRC.db');
    $sql = "SELECT * FROM 'Manufacturing Cell Manager' WHERE mcm_id = :logged_in_mcm_id";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':logged_in_mcm_id', $logged_in_mcm_id, SQLITE3_INTEGER);
    $result = $stmt->execute();

    while ($row = $result->fetchArray()) { 
        $arrayResult[] = $row; 
    }
    return $arrayResult;
}

?>
