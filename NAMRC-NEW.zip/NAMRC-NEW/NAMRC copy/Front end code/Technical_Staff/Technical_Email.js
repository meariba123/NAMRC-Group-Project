//Send Emails in Node.js | NodeMailer Tutorial
   //https://youtu.be/L46FwfVTRE0?si=4sgEc-InZ97f-ROZ - used this just to see the basic functionalities 

const nodemailer = require('nodemailer');
const sqlite3 = require('sqlite3').verbose();
const { DateTime } = require('luxon');

// Function to validate email addresses
function isValidEmail(email) {
    // Regular expression for validating email addresses
    const re = /\S+@\S+\.\S+/; //How can I validate an email address in JavaScript? 10 revs, 10 users 33% C. Lee https://stackoverflow.com/questions/46155/how-can-i-validate-an-email-address-in-javascript 
   
    //used basic functionality 
   
    return re.test(email);
}

// Function to send email notification
async function sendEmail(recipient, subject, body) {
    let transporter = nodemailer.createTransport({
        host: 'smtp-mail.outlook.com', // SMTP server details
        port: 587,
        secure: false, // STARTTLS
        auth: {
            user: 'ariba.1.naveed@gmail.com', // Sender email
            pass: '1Cupofmilk' // Sender password
        }
    });

    try {
        let info = await transporter.sendMail({
            from: 'ariba.1.naveed@gmail.com', // Sender email
            to: recipient,
            subject: subject,
            text: body
        });
        console.log("Email sent: %s", info.messageId);
    } catch (error) {
        console.error("Error sending email:", error);
    }
}

// Function to check and send expiry notifications
function sendExpiryNotifications() {
    let db = new sqlite3.Database('../../../NAMRC copy/NAMRC.db');

    // Calculate expiry threshold date (30 days from now)
    let expiryThresholdDate = DateTime.now().plus({ days: 30 }).toISODate();

    // Query for unique email addresses and their corresponding certifications expiring within a month
    let query = `
        SELECT 
            t.tech_email, 
            t.tech_fname, 
            c.certification_name, 
            oc.expiry_date 
        FROM 
            "Technical Staff" t 
        INNER JOIN 
            "Operator Certification" oc ON (t.tech_ID = oc.tech_ID) 
        INNER JOIN 
            Certifications c ON (c.certification_ID = oc.certification_ID) 
        WHERE 
            oc.expiry_date <= '${expiryThresholdDate}'`;

    db.all(query, [], async (err, rows) => {
        if (err) {
            throw err;
        }
        
        for (let row of rows) {
            let email = row.tech_email;
            if (isValidEmail(email)) {
                let tech_fname = row.tech_fname;
                let subject = "Certification Expiry Notification";
                let body = `Dear ${tech_fname},\n\nYour certifications are expiring soon. Please check your individual certifications for details and renew them as soon as possible.\n\nBest regards,\nNAMRC`;
                await sendEmail(email, subject, body);
            } else {
                console.log(`Invalid email address: ${email}`);
            }
        }
    });

    db.close();
}

// Execute the function to send expiry notifications
sendExpiryNotifications();
